/*/#include <iostream>
#include  <string>
#include <math.h>
using namespace std;

int main()
{
	/*cout << "Hello world" << endl;

	cout<<"7 + 3"<<7+3<<endl;
	cout << 876.12 << endl;
	cout << "f" << endl;
	int number;
	cout << "Enter your fauvorite number" << endl;
	cin >> number�;*/


	*//return 0;*/
		//������ ������� ��������
float side;
cout << "Enter the side" << endl;
cin >> side; 
s= side*side 
cout << "S=" << s << endl;
cout << "P=" << 4 * side << endl;
return 0;